-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2024 at 09:03 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tugaslaundry`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_order_masuk` (IN `order_no` VARCHAR(255), IN `dibayar` DECIMAL(10,2))   BEGIN
    DECLARE sisa_bayar_order DECIMAL(10, 2);

    -- Ambil nilai sisa_bayar dari tabel order_masuk
    SELECT sisa_bayar INTO sisa_bayar_order
    FROM order_masuk
    WHERE no_order = order_no;

    -- Perbarui nilai kolom sisa_bayar di tabel order_masuk
    UPDATE order_masuk
    SET sisa_bayar = sisa_bayar_order - dibayar
    WHERE no_order = order_no;

    -- Perbarui nilai kolom status di tabel order_masuk
    IF sisa_bayar_order - dibayar <= 0 THEN
        UPDATE order_masuk
        SET status = 'Lunas'
        WHERE no_order = order_no;
    ELSE
        UPDATE order_masuk
        SET status = 'Belum Lunas'
        WHERE no_order = order_no;
    END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `NIK` varchar(16) NOT NULL,
  `Nama` varchar(40) NOT NULL,
  `Alamat` varchar(100) NOT NULL,
  `Jenis_kelamin` varchar(1) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`NIK`, `Nama`, `Alamat`, `Jenis_kelamin`, `username`, `password`) VALUES
('1276584934084536', 'Anita', 'Medan', 'P', 'nita', '121212'),
('1678475635647', 'Oktriana', 'Gang Duku', 'P', 'oktri', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_cucian`
--

CREATE TABLE `jenis_cucian` (
  `kd_jenis` int(11) NOT NULL,
  `jenis_cuci` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jenis_cucian`
--

INSERT INTO `jenis_cucian` (`kd_jenis`, `jenis_cuci`) VALUES
(1, 'Pakaian'),
(2, 'Sepatu'),
(3, 'Jas'),
(4, 'Kebaya'),
(5, 'Boneka'),
(6, 'Selimut');

-- --------------------------------------------------------

--
-- Table structure for table `order_masuk`
--

CREATE TABLE `order_masuk` (
  `no_order` varchar(255) NOT NULL,
  `nama_pelanggan` varchar(50) NOT NULL,
  `kd_jenis` int(11) NOT NULL,
  `kd_paket` int(11) NOT NULL,
  `jenis_cuci` varchar(100) NOT NULL,
  `keterangan` text NOT NULL,
  `jenis_paket` varchar(50) NOT NULL,
  `berat` double NOT NULL,
  `harga_total` double NOT NULL,
  `dp` double NOT NULL,
  `sisa_bayar` double NOT NULL,
  `status` varchar(50) NOT NULL,
  `tanggal_masuk` date NOT NULL,
  `jam` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_masuk`
--

INSERT INTO `order_masuk` (`no_order`, `nama_pelanggan`, `kd_jenis`, `kd_paket`, `jenis_cuci`, `keterangan`, `jenis_paket`, `berat`, `harga_total`, `dp`, `sisa_bayar`, `status`, `tanggal_masuk`, `jam`) VALUES
('ORD000001', 'Emia Ginting', 1, 2, '1 - Pakaian', 'baju dan kemeja 10 pasang', 'Cuci + Kering', 6, 48000, 0, -2000, 'Lunas', '2024-02-01', '21:06:00'),
('ORD000002', 'Emia Ginting', 1, 2, '1 - Pakaian', '5 pasang celana panjang', 'Cuci + Kering', 5, 40000, 0, -10000, 'Lunas', '2024-02-01', '21:09:25'),
('ORD000003', 'Oktriana', 1, 3, '1 - Pakaian', '5 pasang baju', 'Setrika', 5, 15000, 0, -5000, 'Lunas', '2024-02-01', '21:12:08');

-- --------------------------------------------------------

--
-- Table structure for table `paket`
--

CREATE TABLE `paket` (
  `kd_paket` int(11) NOT NULL,
  `kd_jenis` int(11) DEFAULT NULL,
  `jenis_paket` varchar(50) DEFAULT NULL,
  `harga` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `paket`
--

INSERT INTO `paket` (`kd_paket`, `kd_jenis`, `jenis_paket`, `harga`) VALUES
(1, 1, 'Cuci + Basah', 7000),
(2, 1, 'Cuci + Kering', 8000),
(3, 2, 'Cuci + Basah', 6000),
(4, 1, 'Setrika', 3000);

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(100) NOT NULL,
  `nama_pelanggan` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `no_telp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama_pelanggan`, `alamat`, `no_telp`) VALUES
(1, 'Emia Ginting', 'medan', '090987651234'),
(2, 'Oktriana', 'Gg.Duku', '083456728312'),
(3, 'Yunita', 'Gg.Bahagia', '0885765745');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `no_transaksi` varchar(11) NOT NULL,
  `no_order` varchar(255) DEFAULT NULL,
  `nama_pelanggan` varchar(50) NOT NULL,
  `tgl_transaksi` date DEFAULT NULL,
  `sisa_bayar` double DEFAULT NULL,
  `dibayar` double NOT NULL,
  `kembalian` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`no_transaksi`, `no_order`, `nama_pelanggan`, `tgl_transaksi`, `sisa_bayar`, `dibayar`, `kembalian`) VALUES
('TRN000001', 'ORD000001', 'Emia Ginting', '2024-02-01', 48000, 50000, 2000),
('TRN000002', 'ORD000002', 'Emia Ginting', '2024-02-01', 40000, 50000, 10000),
('TRN000003', 'ORD000003', 'Oktriana', '2024-02-01', 15000, 20000, 5000),
('TRN000004', 'ORD000001', 'Emia Ginting', '2024-02-01', -2000, 0, 2000),
('TRN000005', 'ORD000002', 'Emia Ginting', '2024-02-01', -10000, 0, 10000),
('TRN000006', 'ORD000003', 'Oktriana', '2024-02-01', -5000, 0, 5000);

--
-- Triggers `transaksi`
--
DELIMITER $$
CREATE TRIGGER `after_transaksi_insert` AFTER INSERT ON `transaksi` FOR EACH ROW BEGIN
    CALL update_order_masuk(NEW.no_order, NEW.dibayar);
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`NIK`);

--
-- Indexes for table `jenis_cucian`
--
ALTER TABLE `jenis_cucian`
  ADD PRIMARY KEY (`kd_jenis`);

--
-- Indexes for table `order_masuk`
--
ALTER TABLE `order_masuk`
  ADD PRIMARY KEY (`no_order`),
  ADD KEY `kd_jenis` (`kd_jenis`),
  ADD KEY `kd_paket` (`kd_paket`);

--
-- Indexes for table `paket`
--
ALTER TABLE `paket`
  ADD PRIMARY KEY (`kd_paket`),
  ADD KEY `kd_jenis` (`kd_jenis`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`no_transaksi`),
  ADD KEY `no_order` (`no_order`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jenis_cucian`
--
ALTER TABLE `jenis_cucian`
  MODIFY `kd_jenis` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `paket`
--
ALTER TABLE `paket`
  MODIFY `kd_paket` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_masuk`
--
ALTER TABLE `order_masuk`
  ADD CONSTRAINT `order_masuk_ibfk_1` FOREIGN KEY (`kd_jenis`) REFERENCES `jenis_cucian` (`kd_jenis`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_masuk_ibfk_2` FOREIGN KEY (`kd_paket`) REFERENCES `paket` (`kd_paket`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `paket`
--
ALTER TABLE `paket`
  ADD CONSTRAINT `paket_ibfk_1` FOREIGN KEY (`kd_jenis`) REFERENCES `jenis_cucian` (`kd_jenis`);

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`no_order`) REFERENCES `order_masuk` (`no_order`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
